const production = "false";
const host = "10.62.7.32";
const port = "8950";
// const host = "127.0.0.1";
// const port = "18950";
const apiUrl = `https://${host}:${port}/ui-new/api-naru`;
// const apiDummy = `src/assets/json/`;
const apiDummy = `/data/`;
// const api = 'http://192.168.1.39:9000/';
const api = 'data/';



export { production, apiUrl,apiDummy,api };